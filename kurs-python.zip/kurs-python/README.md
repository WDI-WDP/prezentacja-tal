# Python — programowanie do matury rozszerzonej

Kurs obejmuje 12 kart pracy dla uczniów znających podstawy Pythona. Początkowe lekcje są powtórzeniem, a kolejne rozwijają umiejętności potrzebne w zadaniach maturalnych. Prowadzący: por. Jakub GRĄTKIEWICZ · jakub.gratkiewicz@wat.edu.pl.

Zacznij od [organizacji i zasad zajęć](00_organizacja_i_zasady_zajec.md). Nie ma sprawdzianów: oceniane są zadania, odpowiedzi dotyczące zadań, kartkówki i aktywność. Każda kartkówka poprzedza część dydaktyczną i trwa 10 minut. Karty nie zawierają szacunków czasu wykonania ćwiczeń.

## Lekcje

Każda lekcja ma osobny folder, własny notatnik `karta_pracy.ipynb` i potrzebne dane obok niego. Łącznie są 144 zadania: 120 na lekcji i 24 do samodzielnego wykonania. Karty 1–4 zawierają po 14 zadań, karty 6, 7, 9 i 11 — po 12, a karty maturalne 5, 8, 10 i 12 — po 10. Ostatnie dwa zadania każdej karty wykonujemy samodzielnie. Pytania do powtórzenia w kartach nie są zestawami kartkówek.

Nowe zadania powtórzeniowe obejmują m.in. szyfrowanie wiadomości, podpowiedzi do sejfu, rozliczanie kawiarni i punktację ligi. Kolejne ćwiczenia łączą te umiejętności z systemami liczbowymi, zliczaniem, sumami prefiksowymi oraz sterowaniem łazikiem. Zadania są wplecione w tok lekcji, przed pracą samodzielną.

| Nr | Karta pracy | Zakres |
|---:|---|---|
| 1 | [Powtórzenie Pythona: Jupyter, obliczenia i sterowanie](01_jupyter_i_podstawy_pythona/karta_pracy.ipynb) | Typy, operatory, warunki, pętle i stan jądra |
| 2 | [Powtórzenie: napisy, kolekcje i funkcje](02_kolekcje_napisy_i_funkcje/karta_pracy.ipynb) | Kopie, palindromy, słowniki, parametry i wyniki funkcji |
| 3 | [Powtórzenie: samodzielna praca z plikami](03_pliki_tekstowe_i_wyniki/karta_pracy.ipynb) | Otwieranie, odczyt, konwersja, kontrola i zapis |
| 4 | [Cyfry, systemy liczbowe i NWD](04_cyfry_skroty_i_nwd/karta_pracy.ipynb) | Horner, skrót, Euklides i własny odczyt danych |
| 5 | [Matura 2024 — Nieparzysty skrót](05_matura_2024_zadanie_3_nieparzysty_skrot/karta_pracy.ipynb) | Zadanie 3.1–3.3 od pliku do odpowiedzi |
| 6 | [Sortowanie, liczności i czynniki](06_sortowanie_zliczanie_i_czynniki/karta_pracy.ipynb) | Duplikaty, dzielniki i zapas czynników |
| 7 | [Sumy prefiksowe i fragmenty](07_sumy_prefiksowe_i_fragmenty/karta_pracy.ipynb) | Granice, złożoność, średnie i remisy |
| 8 | [Matura 2024 — Liczby](08_matura_2024_zadanie_4_liczby/karta_pracy.ipynb) | Zadanie 4.1–4.4, dane przykładowe i pełne |
| 9 | [Napisy, system trójkowy i siatki](09_napisy_system_trojkowy_i_siatki/karta_pracy.ipynb) | Systemy 2/3/8/16, palindromy i bloki 3×3 |
| 10 | [Matura 2025 — Zapis symboliczny](10_matura_2025_zadanie_2_zapis_symboliczny/karta_pracy.ipynb) | Zadanie 2.1–2.4 i samodzielny zapis wyników |
| 11 | [Wektory, punkty i geometria](11_nwd_ruch_i_geometria/karta_pracy.ipynb) | Trasa z pliku, NWD, wnętrze i środek odcinka |
| 12 | [Matura 2025 — Dron](12_matura_2025_zadanie_3_dron/karta_pracy.ipynb) | Zadanie 3.1–3.2 i obrona całego rozwiązania |

Oryginalne zadania CKE są wyraźnie oznaczone rokiem, numerem i symbolem arkusza. Na kartach 5, 8, 10 i 12 PDF odpowiedniego arkusza znajduje się także w folderze lekcji. Kurs obejmuje cztery zadania programistyczne z arkuszy 2024 i 2025; nie obejmuje ich części bazodanowej i arkusza kalkulacyjnego.

## Jak pracować

1. Odbierz od prowadzącego katalog lekcji z notatnikiem i danymi. Jeśli otrzymasz archiwum, rozpakuj je. Nie przenoś samego notatnika bez jego danych.
2. Otwórz `karta_pracy.ipynb` w folderze lekcji. Jądro Pythona powinno pracować w tym folderze, aby zwykłe nazwy plików wskazywały właściwe dane.
3. Jeśli potrzebujesz środowiska, utwórz je przez `python3 -m venv .venv`, aktywuj i zainstaluj `jupyterlab` poleceniem `python -m pip install jupyterlab`. W Windows polecenie Pythona może mieć nazwę `py`.
4. Uruchom `jupyter lab` i otwórz kartę z odpowiedniego katalogu. Każdą kartę wykonuj w osobnym, świeżym jądrze.
5. Sam napisz kod w komórkach roboczych. W zadaniach plikowych obejmuje to **otwarcie pliku, odczyt, konwersję, obliczenia i zapis odpowiedzi**. Nie ma globalnego loadera ani wstępnie wczytanych danych zadaniowych.
6. Wyświetl wyniki obliczeń i przygotuj się do wyjaśnienia własnego rozwiązania. Pod każdym zadaniem znajduje się pusta komórka na Twój kod.
7. Zapisuj pliki wynikowe obok notatnika, pod nazwami wymaganymi w poleceniach. Nie nadpisuj plików wejściowych. Przed oddaniem zrestartuj jądro, uruchom cały własny kod i zapisz notatnik.

Podane małe przykłady pokazują narzędzia; nie wczytują plików zadaniowych za ucznia. W lekcji 3 demonstracja otwiera osobny `demo-liczby.txt`, a uczeń sam pracuje na pozostałych plikach. W lekcjach 1–2 nie są potrzebne pliki zewnętrzne.

## Prezentacja i materiały prowadzącego

Gotowa prezentacja jest w sąsiednim folderze `prezentacja-tal`. Zawiera lekcję 0 z zasadami, blok „Konfiguracja środowiska” oraz lekcje 1–12. Blok wprowadzający obejmuje Portal Firmy, PowerShell, Git, klucze SSH, GitHub i pierwszy pełny cykl pracy z repozytorium. Nie zmienia numeracji kart. Nawigacja: **←/→ między lekcjami, ↑/↓ między elementami**. Strona nie zawiera sekcji ani przycisków pobierania; karty pracy i dane przekazuje prowadzący. Karty ucznia, slajdy, druk i archiwa ucznia nie zawierają rozwiązań zadań ani zestawów kartkówek.

W pełnym lokalnym projekcie folder `materialy-prowadzacego` zawiera:

- `kartkowki_01-12.md` — 12 zestawów po trzy pytania oraz klucz odpowiedzi w jednym pliku;
- `inspiracje_zadan.md` — źródła internetowych inspiracji i powiązanie nowych ćwiczeń z umiejętnościami;
- 12 katalogów z notatnikami `rozwiazania.ipynb` i danymi dla prowadzącego.

Materiały prowadzącego nie są dołączane do publicznych paczek. **Na GitHub Pages publikuj wyłącznie folder `prezentacja-tal`, nie cały lokalny projekt.** Paczka ucznia nie zawiera kluczy ani narzędzi do regenerowania kursu.

## Aktualizacja pełnego projektu

Treść źródłowa jest w `scripts/content`, teksty CKE w `tresci-maturalne`, a oryginalne dane do kopiowania w `dane`. Źródłowe arkusze i wcześniejsze kody C++ zachowano lokalnie w `materialy-zrodlowe`; kody C++ nie są publikowane.

Dodatkowe ćwiczenia zapisano w `scripts/content/creative.py`, a ich pliki wejściowe w `scripts/content/files.py`. Moduł `catalog.py` łączy je z dotychczasowymi zadaniami i zachowuje kolejność wprowadzania teorii.

Po zmianie treści uruchom z katalogu pełnego kursu:

```text
python3 scripts/build-course.py
```

Generator odświeża foldery lekcji, materiały prowadzącego, interfejs prezentacji, slajdy i paczki ucznia. Nie edytuj ręcznie wygenerowanych kopii w prezentacji. Zachowaj własne prace uczniów w oddzielnych kopiach — pełne regenerowanie nadpisuje szablony kart.

Źródła wyglądu i nawigacji znajdują się w `scripts/presentation`, a tekst konfiguracji środowiska w `scripts/presentation/content/konfiguracja-srodowiska.md`. Aby odtworzyć samą stronę w `../prezentacja-tal` wraz z paczkami na podstawie istniejących kart, bez nadpisywania kart i materiałów prowadzącego, uruchom:

```text
python3 scripts/build-course.py --presentation-only
```

Do publikacji wykorzystuj czyste karty ucznia, nie notatniki wypełnione rozwiązaniami. Zachowaj kopię całego lokalnego projektu w osobnym miejscu: publiczne repozytorium prezentacji nie zawiera źródeł generatora ani materiałów prowadzącego.

Po zmianie wyłącznie organizacji zajęć (np. tabeli terminów) wystarczy:

```text
python3 scripts/build-course.py --organization-only
```

Informacje o technicznej weryfikacji materiałów znajdują się w lokalnym `materialy-prowadzacego/README.md`. Nie jest to część zadań ucznia.
